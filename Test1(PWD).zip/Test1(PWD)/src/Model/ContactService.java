package Model;

public class ContactService 
{

	public ContactService()
	{
		
		
	}
	
	public void createContact()
	{
		ContactDAO dao = new ContactDAO();
		dao.CreateContact();
		
	}
	
	public void researchContact()
	{
		ContactDAO dao = new ContactDAO();
		dao.ResearchContact();
		
	}
	
	public void updateContact()
	{
		ContactDAO dao = new ContactDAO();
		dao.UpdateContact();
		
	}
	
	public void deleteContact()
	{
		ContactDAO dao = new ContactDAO();
		dao.DeleteContact();
		
	}
}
