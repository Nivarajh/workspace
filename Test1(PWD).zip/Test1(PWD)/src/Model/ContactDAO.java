package Model;

public class ContactDAO 
{

	public ContactDAO()
	{
		
		
	}
	
	public void CreateContact()
	{
		
		System.out.println("Votre contact � bien �t� ajout�!");
	}
	
	public void ResearchContact()
	{
		
		System.out.println("Votre contact � bien �t� trouv�!");
	}
	
	public void UpdateContact()
	{
		
		System.out.println("Votre contact � bien �t� modifi�!");
	}
	
	public void DeleteContact()
	{
		
		System.out.println("Votre contact � bien �t� supprim�!");
	}
	
	
}
